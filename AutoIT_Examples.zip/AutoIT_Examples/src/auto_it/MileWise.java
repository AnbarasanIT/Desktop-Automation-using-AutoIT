package auto_it;

import org.openqa.selenium.server.SeleniumServer;
import org.testng.annotations.*;

import com.thoughtworks.selenium.DefaultSelenium;
import com.thoughtworks.selenium.SeleneseTestBase;

public class MileWise extends SeleneseTestBase {
	
	SeleniumServer server;
	
	@BeforeClass
	public void setUp() throws Exception
	{
		selenium=new DefaultSelenium("localhost",4444,"*firefox","http://www.eaglecrk.com");
		server=new SeleniumServer();
		server.start();
		selenium.start();
		selenium.windowMaximize();
	}
	
	@Test
	public void sampleTest()
	{
		selenium.open("/industries/case-studies");
		selenium.click("link=Please click here to download the pdf.");
		selenium.type("id=nameText", "Raja");
		selenium.click("name=submit");
		assertEquals("Please enter your company name...", selenium.getAlert());
		selenium.stop();
		server.stop();
	}
}
